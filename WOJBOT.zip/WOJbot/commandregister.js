require('dotenv').config();
const { REST, Routes } = require('discord.js');

const commands = [
  {
    name: 'test',
    description: 'Dummy',
  },
  {
    name: 'stab',
    description: 'dont try yet',
  },
];

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

(async () => {
  try {
    console.log('Registering dem commands');

    await rest.put(
      Routes.applicationGuildCommands(
        process.env.CLIENT_ID,
        process.env.GUILD_ID
      ),
      { body: commands }
    );

    console.log('Worky worky slashy commandy');
  } catch (error) {
    console.log(`YOU DUMB BITCH CANT DO ANYTHING RIGHT: ${error}`);
  }
})();