const { EmbedBuilder, Client, GatewayIntentBits, IntentsBitField, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require('discord.js')
module.exports = client => {
        client.on('guildMemberAdd', member => {
            const channelID = `986456786791981147`;
            const FUCKINGEMBED = new EmbedBuilder() 
            .setColor(0x0099FF)
            .setTitle(`Welcome to the server, <@${member.id}>`)
            .setDescription('Please pick your roles from #Roles')
            console.log(member)
            const message1 = `Heya, <@${member.id}>`;
            const message = `Welcome to World of Japan, <@${member.id}>, please get your japanese level roles from #Roles`;
            const channel = member.guild.channels.cache.get(channelID);
            channel.send({
                embeds: [{
                    type: "rich",
                    image: {
                        url: 'https://ih0.redbubble.net/image.2227503335.5399/raf,360x360,075,t,fafafa:ca443f4786.jpg',
                    },
                    title: `Welcome to World of Japan`,
                    description: `<@${member.id}> Welcome to World of Japan, we hope you enjoy your stay \r\n
                    **And Uninstall Duolingo**`,
                    color: 0xFFFF
                }]
              })
            const dmMessage = `Heya Welcome to World of Japan, <@${member.id}>, please get your japanese level roles from #Roles`;
            member.send(dmMessage).catch(err => {
                console.log(`${err}`)
                return;
            })
            
        })
}