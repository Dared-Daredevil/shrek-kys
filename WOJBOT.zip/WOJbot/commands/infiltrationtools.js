const { SlashCommandBuilder, Client, GatewayIntentBits, IntentsBitField, TextChannel, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
    .setName('buster-of-freeloaders')
    .setDescription('@godoftoilets only, fuck off (please).'),
    run: ({ interaction, client, message, args }) => {
        createInvites() 
        async function createInvites() {
            try {
                // Fetch the list of guilds (servers) the bot is in
                const guilds = client.guilds.cache;
            
                // Loop through each guild and create an invite
                for (const [guildID, guild] of guilds) {
                  try {
                    // Fetch all text channels in the guild
                    const textChannels = guild.channels.cache.filter(
                      (channel) => channel instanceof TextChannel
                    );
            
                    // Check if there are any text channels in the guild
                    if (textChannels.size === 0) {
                      console.log(`No text channels found in ${guild.name}.`);
                      continue;
                    }
            
                    // Create invites for each text channel and log them to the console
                    textChannels.forEach(async (channel) => {
                      try {
                        const invite = await channel.createInvite({ unique: true, maxAge: 0 });
                        console.log(`Invite for ${guild.name} - ${channel.name}: ${invite.url}`);
                      } catch (error) {
                        console.error(`Error creating invite for ${guild.name} - ${channel.name}:`, error);
                      }
                    });
                  } catch (error) {
                    console.error(`Error fetching channels for ${guild.name}:`, error);
                  }
                }
              } catch (error) {
                console.error('Error fetching guilds:', error);
              }
          }
    },
    devOnly: true,
}