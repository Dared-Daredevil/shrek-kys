const { SlashCommandBuilder } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder().setName('author').setDescription('Bot Author'),
    run: ({ interaction }) => {
        interaction.reply('Made by @godoftoilets');
    },
    devOnly: false,
};