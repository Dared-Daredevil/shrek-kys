const { SlashCommandBuilder, Client, GatewayIntentBits, IntentsBitField, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require('discord.js');
const JishoAPI = require('unofficial-jisho-api');
const Jisho = new JishoAPI();
module.exports = {
    data: new SlashCommandBuilder()
    .setName('search-jisho')
    .setDescription('Looks up words from Jisho')
    .addStringOption((option) => option.setName('word').setDescription('The word you want to search.').setRequired(true)),
    run: ({ interaction }) => {
        let Word = interaction.options.getString('word');
        Jisho.scrapeForPhrase(Word).then((data) => {
            interaction.reply(JSON.stringify(data, null, 0.25)).catch(err => {
                console.log(`${err}`)
                interaction.reply(`Error, Please DM @godoftoilets: ${err}`)
                return;
            })
          });   
  },
}