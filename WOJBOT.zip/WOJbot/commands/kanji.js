const { SlashCommandBuilder, Client, GatewayIntentBits, IntentsBitField, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require('discord.js');
const JishoAPI = require('unofficial-jisho-api');
const Jisho = new JishoAPI();

module.exports = {
    data: new SlashCommandBuilder()
    .setName('kanji')
    .setDescription('Looks up a Kanji from Jisho')
    .addStringOption((option) => option.setName('kanji').setDescription('The kanji you want to search.').setRequired(true)),
    run: ({ interaction }) => {
      const colors = [
        0xFF0000,
        0x00FF00,
        0x0000FF,
      ];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
        let Word = interaction.options.getString('kanji');
        Jisho.searchForKanji(Word).then(result => {
            interaction.reply({ embeds: [{
              type: "rich",
              title: 'Found: ' + result.found,
              description: '**Taught in: **' + result.taughtIn + "\r\n" +
              '**JLPT level: **' + result.jlptLevel + "\r\n" +
              '**Stroke count: **' + result.strokeCount + "\r\n"+
              '**Meaning: **' + result.meaning + "\r\n" +
              '**Kunyomi: **' + JSON.stringify(result.kunyomi) + "\r\n"+
              '**Kunyomi example: **' + JSON.stringify(result.kunyomiExamples[0]) + "\r\n"+
              '**Onyomi: **' + JSON.stringify(result.onyomi) + "\r\n"+
              '**Onyomi example: **' + JSON.stringify(result.onyomiExamples[0]) + "\r\n"+
              '**Radical: **' + JSON.stringify(result.radical) + "\r\n"+
              '**Searched for: **' + Word,
              color: (randomColor),
          }]
        })
          });
        }}