const { SlashCommandBuilder, Client, GatewayIntentBits, IntentsBitField, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
    .setName('getallservers')
    .setDescription('@godoftoilets only'),
    run: async ({ interaction, client, message, args }) => {
        interaction.reply(
            { 
              embeds: [
                new EmbedBuilder()
                .setDescription(
                  client.guilds.cache
                    .map(g => `Guild Name: ${g.name}\n  Total Members: ${g.members.cache.size}\n Guild ID: ${g.id}`).join('\n\n')
                )
              ] 
            }
          )
  },
  devOnly: true,
}