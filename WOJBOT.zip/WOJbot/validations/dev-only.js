module.exports = (interaction, commandobj) => {
    if (commandobj.devOnly) {
        if (interaction.member.id !== '391866213938233345') {
            interaction.reply("Dev Only, ping @godoftoilets if you need access");
            return true;
        }
    }
}