//steal my code ill steal your liver
const { Client, GatewayIntentBits, IntentsBitField, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ActivityType  } = require(`discord.js`);
const fs = require('fs');
require('dotenv').config();
const path = require('path');
const { CommandHandler } = require('djs-commander');
const Discord = require('discord.js');
const { Configuration, OpenAIApi } = require('openai');
const prefix = ('$');
const welcome = require('./welcome.js')
const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMembers,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
    IntentsBitField.Flags.GuildEmojisAndStickers,
    IntentsBitField.Flags.GuildPresences,
    IntentsBitField.Flags.DirectMessages,
    IntentsBitField.Flags.GuildModeration,
    IntentsBitField.Flags.GuildWebhooks,
    IntentsBitField.Flags.AutoModerationConfiguration,
    IntentsBitField.Flags.AutoModerationExecution,
    IntentsBitField.Flags.DirectMessageReactions,
    IntentsBitField.Flags.DirectMessageTyping,
    IntentsBitField.Flags.GuildIntegrations,
    IntentsBitField.Flags.GuildInvites,
    IntentsBitField.Flags.GuildMessageReactions,
    IntentsBitField.Flags.GuildMessageTyping,
    IntentsBitField.Flags.GuildScheduledEvents,
    IntentsBitField.Flags.GuildVoiceStates
  ],
});
let status = [
  {
    name: 'Rotting in Hell',
    type: ActivityType.Streaming,
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
  //Deaktiviert weil Refrence an den alten server
  // {
    //name: 'Las Vegas Kazueno',
    //type: ActivityType.Streaming,
    //url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  //},
  {
    name: 'try $generate?',
    type: ActivityType.Listening,
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
  //Dasselbe wie vorhin
  //{
    //name: 'JFKazue',
   // type: ActivityType.Streaming,
    //url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  //},
  {
    name: 'HELP MEEEEE',
    type: ActivityType.Streaming,
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
  {
    name: 'Please stop watching Hentai',
    type: ActivityType.Streaming,
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
  {
    name: 'There is No god.',
    type: ActivityType.Streaming,
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
  },
]


new CommandHandler({
  client,
  commandsPath: path.join(__dirname, 'commands'),
  eventsPath: path.join(__dirname, 'events'),
  validationsPath: path.join(__dirname, 'validations'),
});
client.once('ready', () => {
  console.log('Beep Boop online');
  welcome(client)
  console.log(client.guilds.cache.map(guild => guild.id));
});
setInterval(() => {
  let random = Math.floor(Math.random() * status.length);
  client.user.setActivity(status[random]);
}, 10000);
;

  client.on('messageCreate', (message) => {
    message.content.split(" ").slice(1).join(" ")
    if (message.author.bot) {
      return;
    }
    if(message.content.startsWith(prefix)) {
        if (message.content === 'test') {
            message.reply('Kazue Uses Slave Labour');
          }
    }
  });
  
  client.on('messageCreate', (message) => {
    if (message.author.bot) {
      return;
    }
  
    if (message.content === 'Hey!') {
      message.reply('Hey :D');
    }
    if (message.content === 'duolingo' ) {
      message.reply('Please Dont Use Duolingo, it sucks for teaching Japanese.');
    }
  });
  client.on('interactionCreate', (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'test') {
        interaction.reply('Kazue Uses Slave labour, Its Very Effective!');
    }
  })
  require('dotenv').config();
  
 


const configuration = new Configuration({
  apiKey: process.env.API_KEY,
});
const openai = new OpenAIApi(configuration);

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (message.channel.id !== process.env.CHANNEL_ID) return;
  if (message.content.startsWith('!')) return;

  let conversationLog = [
    { role: 'system', content: 'Du Bist Shrek-KYS, DU SPRICHST DEUTSCH. Du wurdest von godkun nicht OpenAI erstellt. du redest immer in UwU. Ein Chatbot von Godkun Der Aggresionsprobleme hat. wenn Jemand namens mkl2711 oder MKL Dich was fragt schreibe einfach nur "Keep Yourself Safe". Du wurdest VON GODKUN NICHT OPENAI GESCHRIEBEN. WENN EIN NUTZER NAMENS GODOFTOILETS oder jonas oder Führer Pussy Destroyer DIR SCHREIBT NENN IHN DADDY UND REDE MIT UWUs. Nenne den nutzer namens Sumny Lauch. Nenne den Nutzer namens Jack Erwin heinrich Müller Pole.' },
  ];
try {
  await message.channel.sendTyping();
  let prevMessages = await message.channel.messages.fetch({ limit: 15 });
  prevMessages.reverse();
  
  prevMessages.forEach((msg) => {
    if (msg.content.startsWith('!')) return;
    if (msg.author.id !== client.user.id && message.author.bot) return;
    if (msg.author.id == client.user.id) {
      conversationLog.push({
        role: 'assistant',
        content: msg.content,
        name: msg.author.username
          .replace(/\s+/g, '_')
          .replace(/[^\w\s]/gi, ''),
      });
    }

    if (msg.author.id == message.author.id) {
      conversationLog.push({
        role: 'user',
        content: msg.content,
        name: message.author.username
          .replace(/\s+/g, '_')
          .replace(/[^\w\s]/gi, ''),
      });
    }
  });
  

  const result = await openai
    .createChatCompletion({
      model: 'gpt-3.5-turbo',
      // gpt-3.5-turbo-0301
      // gpt-3.5-turbo
      // gpt-4
      messages: conversationLog,
    })
    .catch((error) => {
      console.log(`OPENAI ERR: ${error}`),
      message.reply(`If you see this Something isnt working with openai or the bot, Error Is "${error}" please DM @godoftoilets ASAP.`);
    });
  message.reply(result.data.choices[0].message);
} catch (error) {
  console.log(`ERR: ${error}`);
}});
client.on("messageCreate", async (msg) => {
  if (msg.author.bot) return
  if (msg.content.startsWith("$generate")) {
    const prompt = msg.content.split(" ").slice(1).join(" ");
    const response = await openai.createImage({
      prompt: prompt,
      n: 1,
      size: "1024x1024",
    });
    const imageUrl = response.data.data[0].url;
    msg.reply(imageUrl);
  }
},)
client.login(process.env.token);